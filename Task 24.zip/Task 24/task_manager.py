# import datetime and os
import datetime
import os

name = " "
p_word = " "
login = {}
username = ""
password = ""

# Opened user.txt file to get user's passwords and usernames:
with open("user.txt","r+") as f:
    for line in f:
        line_list = line.strip("\n").split(",")
        p_word = line_list.pop(1)
        name = line_list.pop(0)
        login[name] = p_word # Saved it to a dictionary

# while-loop was used,to see if user enters a valid password and valid username:
while True:
    if username == "":
        username = input("Enter your username?")

    if username not in login:
        print("Username invalid")
        username = ""
    else:
        password = input("Enter your password?")
        if password != login[username]:
            print("Password invalid")
            password = ""
        else:
            break

#This part is all the functions that were used in this project:
# this function is made to register a user:
def reg_user(user,list_user,new_pw,confirm_pw):
    if user not in list_user.keys():
        if new_pw == confirm_pw:
                with open("user.txt","a+") as f:
                    f.write(f"\n{user},{new_pw}")
        else:
            print("Your passwords is not matching, retry again...")

    else:
        new_user = input("Entered the same user, enter a another user?")
        if new_user not in list_user.keys():
            if new_pw == confirm_pw:
                with open("user.txt","a+") as f:                    
                    f.write(f"\n{new_user},{new_pw}")
            else:
                print("Your passwords is not matching, retry again...")

# This function will add the task to task.txt:
def add_task(username, title_of_task, discription_of_task, due_date,current_date,task_done):
    with open("tasks.txt","a+") as f:
        f.write(f"""\n{username}, {title_of_task}, {discription_of_task}, {due_date}, {current_date}, {task_done}""" )

#This function was used to view all the tasks
def view_all():
    with open("tasks.txt","r+") as f:       
        for line in f:
            list_task = line.split(",")

            print(f"""Task : {list_task[1]} """)
            print(f"""Assigned to : {list_task[0]}""" )
            print(f"""Date assigned : {list_task[3]}""")
            print(f"""Due date : {list_task[4]}""")
            print(f"""Task complete? {list_task[5]}""")
            print(f"""Task description:\n {list_task[2]}\n""")

# This function was used to view only certian users' task
# All those certian tasks of a user is saved in a dictionary so that it can be called apon later in project            
def view_mine():
    num_task = 0
    
    with open("tasks.txt","r+") as f:
        for line in f:
            each_line = line.split(",")        
                        
            if username == each_line[0]:
                num_task = num_task + 1  
                print(f"""{num_task} Task : {each_line[1]} """)
                print(f"""Assigned to : {each_line[0]}""" )
                print(f"""Date assigned : {each_line[3]}""")
                print(f"""Due date : {each_line[4]}""")
                print(f"""Task complete? {each_line[5]}""")
                print(f"""Task description:\n {each_line[2]} \n""")
                
                each_task = (f"""{num_task}Task : {each_line[1]} 
            Assigned to : {each_line[0]}
            Date assigned : {each_line[3]}
            Due date : {each_line[4]}
            Task complete? {each_line[5]}
            Task description:\n {each_line[2]} \n""")
                
                
                dict_task[num_task] = each_task

#This function is used to get a specific task:               
def specific_task(num,dict_task):
    if num >= 1:
        print(f"{dict_task[num]}")        
    else:
        return menu
    
def view_mine_task():
    dict_task = {}                                          # empty dictionary is made to use it in the function below
    view_mine()                                             # this function will only present the admin user's tasks
    
    # Asked if the user wants to work with specific task:        
    ask_specify = input("Do you want to specify a task?'yes'/'no'").lower()
            
    # A if-statement is used if user enters "yes" to specify a task 
    if ask_specify == "yes":
    
        specific_num = int(input("Enter a number you want call apon task or -1 to return to menu?"))# Ask for specific number for a task:
        specific_task(specific_num,dict_task)               # Used function to get that specific task
        complete_or_edit = input("Enter if you have completed this task or want to edit this task?Just enter 'edit' or 'done'").lower()# Ask user if they want to edit the task or want to mark it as complete
    
    # If-elif-statement is used to dertermine if the user chose 'done' or complete:             
        if complete_or_edit == "done":
            # opened the tasks file again:                   
            with open("tasks.txt","r+") as f:
                num_line = 0                                # Default value for number of task
                second_dict_tasks = {}                      # Empty dictionary is made
                        
            # each line of the file is read 
                for line in f:
                    each_line = line.split(",") 
                    num_line = num_line + 1
                            
                                
                    if num_line == specific_num:            # If statement is used to dertermine specific tassk
                        each_line[5] = "Yes"                # Changed the task to completed                            
                        join_line = ",".join(each_line)     # join function was used to join the list
                                
                                                                                    
                    with open("tasks.txt","w+") as f:               # Tasks.txt was opened again to overwrite it and add the tasks's new info agaim
                        if num_line != specific_num:
                            f.write(f"{line}")
                            f.write(f"{join_line}")
                                                                                             
        elif complete_or_edit == "edit":
            # Opened file to read the lines and find the specific task
            with open("tasks.txt","r") as f:
                number_line = 0
                change_user_or_due_date = input("Do you want to change the user or due date?").lower() 
                        
            # Then we used the for-loop to go through lines and dertermine if the user wants to edit username or due date
                for line in f: 
                    each_line = line.split(",")
                    number_line = number_line + 1
                            
                    if number_line == specific_num:
                        if change_user_or_due_date == "user":
                            each_line[0] = input("To what user do you want to change it to?")
                            join_new_username = ",".join(each_line)
                                    
                            with open("tasks.txt","w") as o:    # Overwrite the task and change it
                                o.write(line)
                                o.write(join_new_username)
                                        
                        elif change_user_or_due_date == "due date" :
                            each_line[3] = input("To what due date do you want to change it to?")
                            join_new_due_date = ",".join(each_line)
                                    
                            with open("tasks.txt","w") as o:    # Overwrite and change the due date of the specific task
                                o.write(line)
                                o.write(join_new_due_date)
    

# This function is used to get the statistics of the reports:
def statistics():
#Checked if the files are generated
    if not os.path.exists("/task_overview.txt") or not os.path.exists("/user_overview.txt"):
        run_report()                                           # re-used this as a function

#Read the files and generated them
    with open("task_overview.txt","r") as t, open("user_overview.txt","r") as u:
        print("---------Task Overview--------\n")
        for line in t:
            print(line.strip("\n"))

        print("\n---------User Overview--------\n")

        for line in u:
            print(line.strip("\n"))
                
        print("------------------------------\n")
        
# This function is used to get the statistics of the amount of user and tasks
def stactics_users_tasks():
    total_tasks = 0
    total_users = 0

    with open("tasks.txt","r+") as f:
        with open("user.txt","r+") as o:
            for line in o:
                total_users = total_users + 1

            for line in f:
                total_tasks = total_tasks + 1

                
            print(f"Total tasks : {total_tasks}")
            print(f"Total users : {total_users}") 

                
# This function is used to get the total completed tasks            
def total_completed_task(total_completed,user = ""):
    with open("tasks.txt","r") as f:
        for line in f:
            each_line = line.split(",")
            
            if user == "" or each_line[0].strip(" ") == user:
                if each_line[5].lower().strip(" ").strip("\n") == "yes":
                    total_completed = total_completed + 1
                                    
    return total_completed 

# This function is used to get the total uncompleted tasks
def total_uncompleted_task(total_uncompleted,user = ""):
    with open("tasks.txt","r") as f:
        for line in f:
            each_line = line.split(",")
            
            if user == "" or each_line[0].strip(" ") == user:
                if each_line[5].lower().strip("\n").strip(" ") == "no":
                    total_uncompleted = total_uncompleted + 1
                                    
    return total_uncompleted 

# This function gives the total tasks that are overdue and uncompleted                
def report_on_not_done_and_overdue(total_tasks_uncompleted_and_overdue,user = ""):
    with open("tasks.txt","r") as f:
        for line in f:
            each_line = line.split(",")

            if user == "" or each_line[0].strip(" ") == user:
                inc = each_line[5].lower().strip("\n").strip(" ") == "no"
                due = datetime.datetime.strptime(each_line[3].strip(" "), "%d %b %Y")
                cur = datetime.datetime.strptime(each_line[4].strip(" "), "%d %b %Y")
            
                if inc and due > cur:
                    total_tasks_uncompleted_and_overdue = total_tasks_uncompleted_and_overdue + 1 
    return total_tasks_uncompleted_and_overdue
 
#This function gives the percentage of uncompleted tasks                
def per_uncompleted_tasks(percentage_uncompleted_task,total_tasks,total_uncompleted):
    if total_tasks != 0 :
        percentage_uncompleted_task = percentage_uncompleted_task + ((total_uncompleted/total_tasks) * 100)       
    return percentage_uncompleted_task       

#This function gives the total tasks overdue                  
def report_overdue(total_tasks_overdue,user = ""):
    with open("tasks.txt","r") as f:
        for line in f:
            each_line = line.split(",")

            if user == "" or each_line[0].strip(" ") == user:
                due = datetime.datetime.strptime(each_line[3].strip(" "), "%d %b %Y")
                cur = datetime.datetime.strptime(each_line[4].strip(" "), "%d %b %Y")
            
                if due > cur:
                    total_tasks_overdue = total_tasks_overdue + 1
                  
    return total_tasks_overdue

#This function gives the percentage of  the total tasks overdue
def  per_overdue_tasks(percentage_overdue_task,total_tasks,tasks_overdue):
    if total_tasks != 0:
        percentage_overdue_task = percentage_overdue_task + ((tasks_overdue/total_tasks) * 100)        
    return percentage_overdue_task      

def run_report():
    total_tasks                         = 0 # default values for the tasks
    total_users                         = 0 # default values for the total users
    total_completed                     = 0 # default values for completed tasks
    total_uncompleted                   = 0 # default values for uncompleted tsks
    total_tasks_uncompleted_and_overdue = 0 # default values for tasks that are overdue and uncompleted
    percentage_uncompleted_task         = 0 # The starting percentage of uncompleted tasks
    tasks_overdue                       = 0 # default values for total tasks overdue
    percentage_overdue_task             = 0 # The starting percentage of overdue tasks 

    total_users, total_tasks            = stactics_users_tasks()            
    total_completed                     = total_completed_task(total_completed)
    total_uncompleted                   = total_uncompleted_task(total_uncompleted)            
    total_tasks_uncompleted_and_overdue = report_on_not_done_and_overdue(total_tasks_uncompleted_and_overdue)            
    percentage_uncompleted_task         = per_uncompleted_tasks(percentage_uncompleted_task,total_tasks,total_uncompleted)            
    tasks_overdue                       = report_overdue(tasks_overdue)            
    percentage_overdue_task             = per_overdue_tasks(percentage_overdue_task,total_tasks,tasks_overdue)
        
    # To create a file called overview_tasks                                                                                  
    with open("task_overview.txt","w") as f:
        
        f.write(f"""The total tasks that has been generated: {total_tasks}""")
        f.write(f"""\n The total tasks completed: {total_completed}""")
        f.write(f"""\n The total tasks uncompleted: {total_uncompleted}""")
        f.write(f"""\n The total tasks that is overdue and uncompleted: {total_tasks_uncompleted_and_overdue}""")
        f.write(f"""\n The percentage of tasks that is incomplete: {percentage_uncompleted_task}""")
        f.write(f"""\n The percentage of tasks  that is overdue: {percentage_overdue_task}\n""")
        

    with open("user.txt","r") as f, open("user_overview.txt","w") as u:
        for line in f:
            each_line = line.split(",")
            user = each_line[0].strip(" ")

            total_tasks_usr                     = 0 # default values for the tasks assigned to the user
            total_completed                     = 0 # default values for completed tasks
            total_uncompleted                   = 0 # default values for uncompleted tsks
            total_tasks_uncompleted_and_overdue = 0 # default values for tasks that are overdue and uncompleted
            percentage_uncompleted_task         = 0 # The starting percentage of uncompleted tasks
            tasks_overdue                       = 0 # default values for total tasks overdue
            percentage_overdue_task             = 0 # The starting percentage of overdue tasks 

            total_users, total_tasks_usr        = stactics_users_tasks(user)
            if total_tasks != 0:
                per_assigned                    = total_tasks_usr/total_tasks * 100         
            total_completed                     = total_completed_task(total_completed,user)
            if total_tasks_usr != 0:
                per_completed                   = total_completed/total_tasks_usr * 100
            total_uncompleted                   = total_uncompleted_task(total_uncompleted,user)            
            total_tasks_uncompleted_and_overdue = report_on_not_done_and_overdue(total_tasks_uncompleted_and_overdue,user)            
            percentage_uncompleted_task         = per_uncompleted_tasks(percentage_uncompleted_task,total_tasks_usr,total_uncompleted)            
            tasks_overdue                       = report_overdue(tasks_overdue,user)  
            if total_tasks_usr != 0:
                percentage_overdue_task             = total_tasks_uncompleted_and_overdue/total_tasks_usr * 100#per_overdue_tasks(percentage_overdue_task,total_tasks,tasks_overdue)
            
            # To create a file called user_overview   
            u.write(f"""The total tasks assigned to {user}: {total_tasks_usr}""")
            u.write(f"""\n The percentage of total tasks assigned to {user}: {per_assigned}""")
            u.write(f"""\n The percentage of tasks that is complete: {per_completed}""")
            u.write(f"""\n The percentage of tasks that is incomplete: {percentage_uncompleted_task}""")
            u.write(f"""\n The percentage of tasks  that is overdue: {percentage_overdue_task}\n\n""")
                                                                 
while True:
# presenting the menu to the user and 
# making sure that the user input is coneverted to lower case.
    if username == 'admin':
        menu = input('''Select one of the following Options below:
    r - Registering a user
    a - Adding a task
    va - View all tasks
    vm - view my task
    e - Exit
    gr - Generate reports 
    ds - Statistics
    : ''').lower()

        if menu == 'r':
    #Selected if asked for a new usename and password                               
            new_username = input("Enter a new username?")
            new_password = input("Enter a new password?")
            confirm_password = input("Re-enter the password?")

    #Function use to see if the username already exist and to add the new username and new password to user.txt:
            reg_user(new_username,login,new_password,confirm_password)

    # To append a new task to the tasks.txt file:
        elif menu == 'a':
            

    # User inputs new task's info:
            title_of_task = input("Enter task name?")
            discription_of_task = input("Enter task discription?")
            due_date = input("Enter the due date of task?short date version")
            task_done = "No"
            current_date = "13 Okt 2017"

    # Added to tasks.txt and used a function to add the file:
            add_task(username, title_of_task, discription_of_task, due_date,current_date,task_done)
            

    # This will show all exsisting tasks:
        elif menu == 'va':
    # This function will let you view all existing task:     
            view_all()
                    
    # This will only show that specific user's tasks 
        elif menu == 'vm':          
            view_mine_task()
            
    # This was used to generate two reports:                                
        elif menu == "gr":             
            run_report()           
            
            
    # This option will calculate the amount of tasks and users:
        elif menu == 'ds':
            statistics() 
            

        elif menu == 'e':
            print('Goodbye!!!')
            exit()

        else:
            print("You have made a wrong choice, Please Try again")

# This elif-statement are only for users that are not admin:
# It repeats a,va,vm:
    elif username != 'admin':
        menu = input('''Select one of the following Options below:   
    a - Adding a task
    va - View all tasks
    vm - view my task
    e - Exit
    : ''').lower()

        if menu == 'a':           
            title_of_task = input("Enter task name?")
            discription_of_task = input("Enter task discription?")
            due_date = input("Enter the due date of task?short date version")
            task_done = "No"
            current_date = "13 Okt 2017"

            add_task(username, title_of_task, discription_of_task, due_date,current_date,task_done)
    
    # It looks like it does not want to run, please help with this issue:
        elif menu == 'va':                       
            view_all()   
            
        elif menu == 'vm':
            view_mine_task()
            
        elif menu == 'e':
            print('Goodbye!!!')
            exit()

        else:
            print("You have made a wrong choice, Please Try again")
   