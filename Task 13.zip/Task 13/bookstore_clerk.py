#================Import=================
import sqlite3

#============Creating a table===========
# Try-except block used to prevent any errors
try:
    database = sqlite3.connect('ebookstore.db')
    cursor = database.cursor()

    cursor.execute('''CREATE TABLE books(id INTEGER PRIMARY KEY,
                title TEXT,
                author TEXT,
                qty INTEGER) 
                ''')

    database.commit()                       # Save the changes of the table
except Exception as e:
    database.rollback()
    raise e

#======Inserting values in the table======
# Created a list of books that need to be inserted in the table
book_list = [(3001,"The Tale of Two cities","Charles Dickens",30),
            (3002,"Harry Potter and the Philosopher's Stone","J.K Rowling",40),
            (3003,"The Lion, the Witch and Wardrobe","C.S Lewis",25),
            (3004,"The Lord of the Rimgs","J.R.R Tolkien",37),
            (3005,"Alice in Wonderland","Lewis Carroll",12)] 

cursor.executemany('''INSERT INTO books(id,title,author,qty) VALUES(?,?,?,?)''', book_list)

database.commit()

#==============Functions:=================
# Function that enters a book to the ebook-database
def enter_book():
    # Asking details of the book that needs to be entered in the table
    choice_title = input("Enter the book's title? ")
    choice_author = input("Enter the author of the book? ")
    choice_qty = int(input("Enter the qty of the book of your choice? ")) 
    
    cursor.execute('''INSERT INTO books(title,author,qty) 
                      VALUES(?,?,?)''',(choice_title,choice_author,choice_qty))
    
    database.commit()
    
    # Print-statement for user to know the book is entered in the table
    print("You entered the book successfully in table books!")

# Function that updates a certian book's information    
def update_book():
    # Asking user for the id of the book they want to update
    id_book = int(input("Enter the id of the book you want to update? "))
    
    # Question of what the user wants to update of the record
    update_title = input("Do you want to update the title of the book? ").lower()
    update_author = input("Do you want to update the author of the book? ").lower()
    update_qty = input("Do you want to update the qauntity of the book? ").lower()
    
    # If statements to see what user wants to update:
    if update_title == "yes":
        # Asking user what they want to change the title of the book to
        name_title = input("Enter the updated title of the book: ")
        cursor.execute('''UPDATE books SET title = ? WHERE id = ?''',(name_title,id_book))
        
        database.commit()
        
        print("Successfully updated!")
        
    if update_author == "yes":
        # Asking user what they want to change the author of the book to
        name_author = input("Enter the updated author of the book: ")
        cursor.execute('''UPDATE books SET author = ? WHERE id = ?''',(name_author,id_book))
        
        database.commit()
        
        print("Successfully updated!")
        
    if update_qty == "yes":
        # Asking user what they want to change the qauntity of the book to
        name_qty = input("Enter the updated qauntity of the book: ")
        cursor.execute('''UPDATE books SET qty = ? WHERE id = ?''',(name_qty,id_book))
        
        database.commit()
        
        print("Successfully updated!")

# Function that searches for certian book in the ebooks-database       
def search_book():
    # Ask user for the id of the book they are looking for
    search_id = input("Enter the id of the book you want to search for? ")
    
    cursor.execute('''SELECT * FROM books WHERE id = ?''', (search_id,))
    book = cursor.fetchall()                       # Use the fetchall-function to fetch that certian book
        
    print("The book you searched for: ")
    # For-loop is used to loop through book list  
    for each_book in book:
        print("ID of the book:" + str(each_book[0]))
        print("Title of the book :" + each_book[1])
        print("Author of the book :" + each_book[2])
        print("Qauntity of the book :" + str(each_book[3])) 
        
    database.commit()   

# Function that will delete a certian record off the books-table   
def delete_book():
    # Ask user for the id of the book they want to delete
    ask_id = input("Enter the id of the book you want to delete? ")
    
    cursor.execute('''DELETE FROM books WHERE id = ? ''',(ask_id))
    print("It was successfull!")
    
    database.commit()
    
#===========Main menu===============
menu = True

# While loop is used to present the main menu the whole time after a certian selection
while True:
    main_menu = int(input('''Choose the folowing options:
                          1 - Enter a book
                          2 - Update a book
                          3 - Delete a book
                          4 - Search for a book
                          5 - Exit
                          : '''))
    
    # If-statements used to compare with user's input to see which option it must perform
    if main_menu == 1:
        enter_book()
    elif main_menu == 2:
        update_book()
    elif main_menu == 3:
        delete_book()
    elif main_menu == 4:
        search_book()
    elif main_menu == 5:
        print("Goodbye fellow user!")
        database.close()
        exit()
    else:
        print("This option does not exsist,please try again...")

    
    
        
        