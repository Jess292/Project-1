usernames = []
passwords = []
name = " "
p_word = " "

with open("user.txt","r+") as f:
    for line in f:
        line_list = line.strip("\n").split(",")
        p_word = line_list.pop(1)
        name = line_list.pop(0)
        passwords.append(p_word)
        usernames.append(name)


print(usernames)
print(passwords)

username = input("Enter your username?")
password = input("Enter your password?")
    
# while-loop was used,to see if user enters a valid password and username:
while username not in usernames and password not in passwords:
    username = input("Enter a valid  username?")
    password = input("Enter a valid password?")

while True:
    #presenting the menu to the user and 
    # making sure that the user input is coneverted to lower case.
    if username == 'admin':
        menu = input('''Select one of the following Options below:
    r - Registering a user
    a - Adding a task
    va - View all tasks
    vm - view my task
    e - Exit
    s - Statistics
    : ''').lower()


        if menu == 'r':
            pass
            '''In this block you will write code to add a new user to the user.txt file
            - You can follow the following steps:
                - Request input of a new username
                - Request input of a new password
                - Request input of password confirmation.
                - Check if the new password and confirmed password are the same.
                - If they are the same, add them to the user.txt file,
                - Otherwise you present a relevant message.'''

            #Selected if asked for a new usename and password                               
            new_username = input("Enter a new username?")
            new_password = input("Enter a new password?")
            confirm_password = input("Re-enter the password?")

    #If statement is used to see if password matches
            if new_password == confirm_password:
                with open("user.txt","a+") as f:
                    f.write(f"\n{new_username},{new_password}")
            else:
                print("Your passwords is not matching, retry again...")
    # To append a new task to the tasks.txt file:
        elif menu == 'a':
            pass
            '''In this block you will put code that will allow a user to add a new task to task.txt file
            - You can follow these steps:
                - Prompt a user for the following: 
                    - A username of the person whom the task is assigned to,
                    - A title of a task,
                    - A description of the task and 
                    - the due date of the task.
                - Then get the current date.
                - Add the data to the file task.txt and'''
    # User inputs new task's info:
            title_of_task = input("Enter task name?")
            discription_of_task = input("Enter task discription?")
            due_date = input("Enter the due date of task?short date version")
            task_done = "No"
            current_date = "13 Okt 2017"

    # Added to file:
            with open("tasks.txt","a+") as f:
                f.write(f"""\n{username} , {title_of_task}, {discription_of_task}, {due_date}, {current_date}, {task_done}""" )

    # This will show all exsisting tasks:
        elif menu == 'va':
            pass
            with open("tasks.txt","r+") as f:
                for line in f:
                    list_task = line.split(",")

                    print(f"""Task : {list_task[1]} """)
                    print(f"""Assigned to : {list_task[0]}""" )
                    print(f"""Date assigned : {list_task[3]}""")
                    print(f"""Due date : {list_task[4]}""")
                    print(f"""Task complete? {list_task[5]}""")
                    print(f"""Task description:\n {list_task[2]}\n""")
                    
    # This will only show that specific user's tasks 
        elif menu == 'vm':
            pass

            with open("tasks.txt","r+") as f:
                for line in f:
                    each_line = line.split(",")        
                        
                    if username == each_line[0]:
                        print(f"""Task :  {each_line[1]} """)
                        print(f"""Assigned to : {each_line[0]}""" )
                        print(f"""Date assigned : {each_line[3]}""")
                        print(f"""Due date : {each_line[4]}""")
                        print(f"""Task complete? {each_line[5]}""")
                        print(f"""Task description:\n {each_line[2]} \n""")
    # This option will calculate the amount of tasks and users:
        elif menu == 's':
            pass

            total_tasks = 0
            total_users = 0

            with open("tasks.txt","r+") as f:
                with open("user.txt","r+") as o:
                    for line in o:
                        total_users = total_users + 1

                    for line in f:
                        total_tasks = total_tasks + 1

                
                    print(f"Total tasks : {total_tasks}")
                    print(f"Total users : {total_users}")    

                          

        elif menu == 'e':
            print('Goodbye!!!')
            exit()

        else:
            print("You have made a wrong choice, Please Try again")

# This elif-statement are only for users that are not admin:
# It repeats a,va,vm:
    elif username != 'admin':
        menu = input('''Select one of the following Options below:   
    a - Adding a task
    va - View all tasks
    vm - view my task
    e - Exit
    : ''').lower()

    if menu == 'a':
        pass

        title_of_task = input("Enter task name?")
        discription_of_task = input("Enter task discription?")
        due_date = input("Enter the due date of task?short date version")
        task_done = "No"
        current_date = "13 Okt 2017"

        with open("tasks.txt","a+") as f:
            f.write(f"""\n{username} , {title_of_task}, {discription_of_task}, {due_date}, {current_date}, {task_done}""" )

   
# It looks like it does not want to run, please help with this issue:
    elif menu == 'va':
        pass
            
        with open("tasks.txt","r+") as f:
            for line in f:
                list_task = line.split(",")

                print(f"""Task : {list_task[1]} """)
                print(f"""Assigned to : {list_task[0]}""" )
                print(f"""Date assigned : {list_task[3]}""")
                print(f"""Due date : {list_task[4]}""")
                print(f"""Task complete? {list_task[5]}""")
                print(f"""Task description:\n {list_task[2]}\n""")

    elif menu == 'vm':
        pass
        
        with open("tasks.txt","r+") as f:
            for line in f:
                each_line = line.split(",")        
                        
                if username == each_line[0]:
                    print(f"""Task :  {each_line[1]} """)
                    print(f"""Assigned to : {each_line[0]}""" )
                    print(f"""Date assigned : {each_line[3]}""")
                    print(f"""Due date : {each_line[4]}""")
                    print(f"""Task complete? {each_line[5]}""")
                    print(f"""Task description:\n {each_line[2]} \n""")

    elif menu == 'e':
        print('Goodbye!!!')
        exit()

    else:
        print("You have made a wrong choice, Please Try again")

    

        






    